declare module '*.png';
declare module '*.jpeg';
declare module '*.svg';
declare module '*.gif';
declare module '*.jpg';
